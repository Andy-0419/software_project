#include "Bike.h"

vector<Bike*> Bike::bike_list;

Bike* Bike::createBike(string bike_id, string bike_name) {
    Bike* new_bike = new Bike();
    new_bike->bike_id = bike_id;
    new_bike->bike_name = bike_name;
    new_bike->rented = "No";
    bike_list.push_back(new_bike);
    return new_bike;
}

void Bike::updateBike(string bike_id, string renter) {
    for (auto b : bike_list) {
        if (b->bike_id == bike_id) {
            b->rented = renter;
            break;
        }
    }
}

vector<Bike*> Bike::getBike(string member_id)
{
    vector<Bike*> rented_bikes;
    for (auto bike : bike_list) {
        if (bike->rented == member_id) {
            rented_bikes.push_back(bike); 
        }
    }
    return rented_bikes;
}
