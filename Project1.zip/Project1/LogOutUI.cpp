#include "LogOutUI.h"

void LogOutUI::tryLogOut(ofstream& out_fp) {
    LogOut logoutControl;
    logoutControl.finishSystem(out_fp);
}
