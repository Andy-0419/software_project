#include "RegistUI.h"

void RegistUI::startInterface(ifstream& in_fp, ofstream& out_fp) {
    string bike_id, bike_name;
    in_fp >> bike_id >> bike_name;
    inputBikeInfo(out_fp, bike_id, bike_name);
}

void RegistUI::inputBikeInfo(ofstream& out_fp, string bike_id, string bike_name) {
    regist = new Regist();
    regist->registBike(bike_id, bike_name);

    out_fp << "3.1. ������ ���\n";
    out_fp << "> " << bike_id << " " << bike_name << "\n";
}
