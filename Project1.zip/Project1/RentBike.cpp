#include "RentBike.h"
#include "Bike.h"
#include "Member.h"

void RentBike::setMember()
{
    this->member = Member::member_list[0];
}

void RentBike::assignBike(string bike_id) {
    setMember();
    string renter = member->getId();
    Bike::updateBike(bike_id, renter);
}