#ifndef LOGOUT_H
#define LOGOUT_H

#include <fstream>

using namespace std;

class LogOut {
public:
    void finishSystem(ofstream& out_fp);
};

#endif

