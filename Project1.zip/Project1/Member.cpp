#include "Member.h"

vector<Member*> Member::member_list;

Member::Member(string id, string pw, int pn) : id(id), pw(pw), phoneNumber(pn) {
    member_list.push_back(this);
}

Member* Member::createMember(string id, string pw, int pn) {
    return new Member(id, pw, pn);
}


Member* Member::checkAccount(string id, string pw) {
    
    if (id == "admin" && pw == "admin") {
        static Member* admin;
        admin->id = "admin";
        admin->pw = "admin";
        return admin;
    }

    for (Member* member : member_list) {
        if (member->id == id && member->pw == pw) {
            return member;
        }
    }
    return nullptr;
}

string Member::getId() const {
    return member_list[0]->id;
}

void Member::initialize() {
    static bool initialized = false;
    if (!initialized) {
        new Member("admin", "admin", 0); // admin ���� �߰�
        initialized = true;
    }
}

vector<Member*> Member::getMemberList() {
    return member_list;
}