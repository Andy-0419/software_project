#ifndef RENTBIKEUI_H
#define RENTBIKEUI_H


#include <fstream>
#include <string>
using namespace std;

class RentBike;

class RentBikeUI {
private:
    RentBike* rentBike;
public:
    void startInterface(ifstream& in_fp, ofstream& out_fp);
    void selectBike(string bike_id);
};

#endif
