#ifndef REGISTUI_H
#define REGISTUI_H

#include "Regist.h"
#include <fstream>
#include <string>

using namespace std;

class RegistUI {
private:
    Regist* regist;
public:
    void startInterface(ifstream& in_fp, ofstream& out_fp);
    void inputBikeInfo(ofstream& out_fp, string bike_id, string bike_name);
};

#endif
