#ifndef RENTBIKE_H
#define RENTBIKE_H
#include "Member.h"

#include <string>
using namespace std;

class RentBikeUI;
class Bike;
class Member;

class RentBike {
private:
    RentBikeUI* rentBikeUI;
    Bike* bike;
    Member* member;
public:
    void setMember();
    void assignBike(string bike_id);
};

#endif
