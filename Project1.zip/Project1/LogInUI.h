#ifndef LOGINUI_H
#define LOGINUI_H

#include <fstream>
#include <string>
#include "LogIn.h"


using namespace std;

class LogInUI {
public:
    void startInterface(ifstream& in_fp, ofstream& out_fp);
    void enterAccount(string id, string pw, ofstream& out_fp);
};

#endif

