
#ifndef CHECKRENTINFO_H
#define CHECKRENTINFO_H

#include <string>
#include "Bike.h"
#include "Member.h"

using namespace std;

class CheckRentInfoUI;

class CheckRentInfo {
private:
    CheckRentInfoUI* checkRentInfoUI;
    Member* member;
public:
    void selectBike(ofstream& out_fp);  // out_fp ����
};

#endif

