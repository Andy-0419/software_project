#ifndef LOGIN_H
#define LOGIN_H

#include <string>
#include "Member.h"

using namespace std;

class LogIn {
public:
    Member* tryLogIn(string id, string pw);
};

#endif

