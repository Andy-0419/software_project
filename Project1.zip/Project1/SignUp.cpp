#include "SignUp.h"

Member* SignUp::signingUp(string id, string pw, int pn)
{
	member = Member::createMember(id, pw, pn);
	return member;
}
