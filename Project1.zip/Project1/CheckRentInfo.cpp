// CheckRentInfo.cpp
#include "CheckRentInfo.h"
#include "CheckRentInfoUI.h"

void CheckRentInfo::selectBike(ofstream& out_fp) {
    string member_id = member->getId();
    vector<Bike*> rented_bikes = Bike::getBike(member_id);

    out_fp << "5.1. ������ �뿩 ����Ʈ\n";
    for (auto bike : rented_bikes) {
        out_fp << "> " << bike->getBikeId() << " " << bike->getBikeName() << "\n";
    }
}
