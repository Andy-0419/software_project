#include "SignUpUI.h"
#include "SignUp.h"

SignUpUI::SignUpUI(SignUp* su) : signUp(su) {}

void SignUpUI::setLink() {
    if (signUp != nullptr)
        signUp->setUI(this);
}

void SignUpUI::startInterface(ifstream& in_fp, ofstream& out_fp)
{
    string id, pw;
    int pn;
    in_fp >> id >> pw >> pn;
    inputInfo(id, pw, pn);
    out_fp << "1.1. ȸ������\n";
    out_fp << "> " << id << " " << pw << " " << pn << "\n";
}

void SignUpUI::inputInfo(string id, string pw, int pn) {
    signUp->signingUp(id, pw, pn);
}
