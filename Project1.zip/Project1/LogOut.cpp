#include "LogOut.h"
#include "Member.h"

void LogOut::finishSystem(ofstream& out_fp) {
    vector<Member*> members = Member::getMemberList();
    string logout_id;

    if (members.size() > 1) {
        logout_id = members[1]->getId();  // �Ϲ� ����� ����
    }
    else {
        logout_id = members[0]->getId();  // admin ����
    }

    out_fp << "2.2. �α׾ƿ�\n";
    out_fp << "> " << logout_id << "\n";
}
