#include "Regist.h"

void Regist::registBike(string bike_id, string bike_name) {
    bike = Bike::createBike(bike_id, bike_name);
}
