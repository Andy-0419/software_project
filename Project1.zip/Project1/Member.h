#ifndef MEMBER_H
#define MEMBER_H

#include <string>
#include <vector>

using namespace std;

class Member {
private:
    string id;
    string pw;
    int phoneNumber;

public:
    static vector<Member*> member_list;
    static void initialize();
    Member(string id, string pw, int pn);
    static Member* createMember(string id, string pw, int pn);
    string getId() const;
    static Member* checkAccount(string id, string pw);
    static vector<Member*> getMemberList();
};

#endif

