#include "LogIn.h"

Member* LogIn::tryLogIn(string id, string pw) {
    return Member::checkAccount(id, pw);
}
