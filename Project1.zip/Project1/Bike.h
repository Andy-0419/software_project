#ifndef BIKE_H
#define BIKE_H

#include <vector>
#include <string>

using namespace std;

class Bike {
private:
    string bike_id;
    string bike_name;
    string rented;

public:
    static vector<Bike*> bike_list;
    static vector<Bike*> getBike(string member_id);
    static Bike* createBike(string bike_id, string bike_name);
    static void updateBike(string bike_id, string renter);
    string getBikeId() const { return bike_id; }
    string getBikeName() const { return bike_name; }
};

#endif

