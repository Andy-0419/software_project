#ifndef REGIST_H
#define REGIST_H

#include "Bike.h"
#include <string>

using namespace std;

class RegistUI;

class Regist {
private:
    RegistUI* registUI;
    Bike* bike;
public:
    void registBike(string bike_id, string bike_name);
};

#endif

