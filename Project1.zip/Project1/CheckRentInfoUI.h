
#ifndef CHECKRENTINFOUI_H
#define CHECKRENTINFOUI_H

#include <fstream>
using namespace std;

class CheckRentInfo;

class CheckRentInfoUI {
private:
    CheckRentInfo* checkRentInfo;
public:
    void startInterface(ifstream& in_fp, ofstream& out_fp);  // ���� ���
};

#endif

