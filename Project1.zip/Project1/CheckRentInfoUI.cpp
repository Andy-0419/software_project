// CheckRentInfoUI.cpp
#include "CheckRentInfoUI.h"
#include "CheckRentInfo.h"

void CheckRentInfoUI::startInterface(ifstream& in_fp, ofstream& out_fp) {
    checkRentInfo->selectBike(out_fp);  // out_fp �Ѱܼ� ���
}
