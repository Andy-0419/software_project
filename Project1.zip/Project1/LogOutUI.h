#ifndef LOGOUTUI_H
#define LOGOUTUI_H

#include "LogOut.h"
#include <fstream>

using namespace std;

class LogOutUI {
public:
    void tryLogOut(ofstream& out_fp);
};

#endif

