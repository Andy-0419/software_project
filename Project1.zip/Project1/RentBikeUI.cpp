#include "RentBikeUI.h"
#include "RentBike.h"


void RentBikeUI::startInterface(ifstream& in_fp, ofstream& out_fp) {
    string bike_id;
    string bike_name;
    in_fp >> bike_id >> bike_name;

    
    out_fp << "4.1. ������ �뿩" << endl;
    out_fp << "> " << bike_id << bike_name << endl;

    selectBike(bike_id);
}

void RentBikeUI::selectBike(string bike_id) {
    rentBike = new RentBike();
    rentBike->assignBike(bike_id);
}
