#ifndef SIGNUP_H
#define SIGNUP_H

#include <string>
#include "Member.h"

using namespace std;
class SignUpUI;

class SignUp {
private:
    SignUpUI* signUpUI;
    Member* member;

public:
    Member* signingUp(string id, string pw, int pn);
    void setUI(SignUpUI* ui) {
        signUpUI = ui;
    }
};


#endif

