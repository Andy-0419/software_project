#include "LogInUI.h"

void LogInUI::startInterface(ifstream& in_fp, ofstream& out_fp) {
    string id, pw;
    in_fp >> id >> pw;
    enterAccount(id, pw, out_fp);
}

void LogInUI::enterAccount(string id, string pw, ofstream& out_fp) {
    LogIn loginControl;
    Member* loginMember = loginControl.tryLogIn(id, pw);

    out_fp << "2.1. �α���\n";
    if (loginMember) {
        out_fp << "> " << id << " " << pw << "\n";
    }
    else {
        out_fp << "> �α��� ����\n";
    }
}
